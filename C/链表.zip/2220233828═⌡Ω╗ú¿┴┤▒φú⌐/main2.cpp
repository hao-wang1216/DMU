#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ����ѧ����Ϣ�ṹ��
typedef struct Student {
    int id;
    char name[50];
    char clas[20];
    char major[50];
    float scores[3];
    struct Student *next;
} STU;

// ��������
void Menu();
STU* CreateList(int n);
void Output(STU *p);
void Save(STU *p);
void Take(STU** Pstu);
STU* Fetch(int id);
STU* Search_num(STU *head, int id);
void InsertList(STU **head, STU *new_student);
void Delete_num(STU **head, int id);
STU* Search_major_subject_score(STU *head, char *major, int subject_index, float score);
void Delete_major_subject(STU **head, char *major, int subject_index, float score);
void AddStudents(STU ** head);

void Menu() {
    printf("ѧ����Ϣ����ϵͳ\n");
    printf("1. ����ѧ������\n");
    printf("2. ���ѧ����Ϣ\n");
    printf("3. ����ѧ����Ϣ���ļ�\n");
    printf("4. ���ļ��ж�ȡѧ����Ϣ\n");
    printf("5. ����ѧ����Ϣ����ѧ�ţ�\n");
    printf("6. ����ѧ����Ϣ\n");
    printf("7. ɾ��ѧ����Ϣ����ѧ�ţ�\n");
    printf("8. �����ض�רҵ�Ϳγ̳ɼ���ѧ��\n");
    printf("9. ɾ���ض�רҵ�Ϳγ̳ɼ���ѧ��\n");
    printf("0. �˳�\n");
}

void InsertList(STU **head, STU *new_student) {
    if (*head == NULL) {
        *head = new_student;
        new_student->next = NULL;
    } else {
        STU *prev = NULL;
        STU *current = *head;
        while (current != NULL && current->id < new_student->id) {
            prev = current;
            current = current->next;
        }
        new_student->next = current;
        if (prev == NULL) {
            *head = new_student;
        } else {
            prev->next = new_student;
        }
    }
}

STU* CreateList(int n) {
    STU *head = NULL;
    for (int i = 0; i < n; i++) {
        STU *new_student = (STU*)malloc(sizeof(STU));
        printf("����ѧ��: ");
        scanf("%d", &new_student->id);
        printf("��������: ");
        scanf("%s", new_student->name);
        printf("����༶: ");
        scanf("%s", new_student->clas);
        printf("����רҵ: ");
        scanf("%s", new_student->major);
        printf("����3�ųɼ�: ");
        for (int j = 0; j < 3; j++) {
            scanf("%f", &new_student->scores[j]);
        }
        InsertList(&head, new_student);
    }
    return head;
}

void Output(STU *p) {
    printf("ѧ��: %d\n", p->id);
    printf("����: %s\n", p->name);
    printf("�༶: %s\n", p->clas);
    printf("רҵ: %s\n", p->major);
    printf("�ɼ�: %.2f, %.2f, %.2f\n", p->scores[0], p->scores[1], p->scores[2]);
}

void Save(STU *head) {
    FILE *file = fopen("students.dat", "wb");
    if (file == NULL) {
        perror("���ļ�ʧ��");
        return;
    }
    STU *current = head;
    while (current != NULL) {
        fwrite(current, sizeof(STU), 1, file);
        current = current->next;
    }
    fclose(file);
}

void Take(STU** Pstu) {
    FILE* fp;
    fp = fopen("students.dat", "rb");
    if (fp == NULL) {
        printf("���ܴ��ļ�\n");
        return;
    }
    STU temp;
    while (fread(&temp, sizeof(STU), 1, fp)) {
        STU *new_student = (STU*)malloc(sizeof(STU));
        *new_student = temp;
        new_student->next = NULL;
        InsertList(Pstu, new_student);
    }
    fclose(fp);
}

STU* Fetch(int id) {
    FILE *file = fopen("students.dat", "rb");
    if (file == NULL) {
        perror("���ļ�ʧ��");
        return NULL;
    }
    STU *student = (STU*)malloc(sizeof(STU));
    while (fread(student, sizeof(STU), 1, file)) {
        if (student->id == id) {
            fclose(file);
            return student;
        }
    }
    fclose(file);
    free(student);
    return NULL;
}

STU* Search_num(STU *head, int id) {
    STU *current = head;
    while (current != NULL) {
        if (current->id == id) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

void Delete_num(STU **head, int id) {
    STU *prev = NULL;
    STU *current = *head;
    while (current != NULL && current->id != id) {
        prev = current;
        current = current->next;
    }
    if (current != NULL) {
        if (prev == NULL) {
            *head = current->next;
        } else {
            prev->next = current->next;
        }
        free(current);
    }
}

STU* Search_major_subject_score(STU *head, char *major, int subject_index, float score) {
    STU *current = head;
    while (current != NULL) {
        if (strcmp(current->major, major) == 0 && current->scores[subject_index] < score) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

void Delete_major_subject(STU **head, char *major, int subject_index, float score) {
    STU *prev = NULL;
    STU *current = *head;
    while (current != NULL) {
        if (strcmp(current->major, major) == 0 && current->scores[subject_index] < score) {
            if (prev == NULL) {
                *head = current->next;
                free(current);
                current = *head;
            } else {
                prev->next = current->next;
                free(current);
                current = prev->next;
            }
        } else {
            prev = current;
            current = current->next;
        }
    }
}

void AddStudents(STU **head) {
    int n;
    printf("����ѧ������: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        STU *new_student = (STU*)malloc(sizeof(STU));
        printf("����ѧ��: ");
        scanf("%d", &new_student->id);
        printf("��������: ");
        scanf("%s", new_student->name);
        printf("����༶: ");
        scanf("%s", new_student->clas);
        printf("����רҵ: ");
        scanf("%s", new_student->major);
        printf("����3�ųɼ�: ");
        for (int j = 0; j < 3; j++) {
            scanf("%f", &new_student->scores[j]);
        }
        InsertList(head, new_student);
    }
}

int main() {
    STU *head = NULL;
    Take(&head);
    int choice, id;
    char major[50];
    int subject_index;
    float score;
    STU *student;

    while (1) {
        Menu();
        printf("��ѡ��: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                AddStudents(&head);
                break;
            case 2:
                if (head == NULL) {
                    printf("����Ϊ�ա�\n");
                } else {
                    STU *current = head;
                    while (current != NULL) {
                        Output(current);
                        current = current->next;
                    }
                }
                break;
            case 3:
                if (head == NULL) {
                    printf("����Ϊ�ա�\n");
                } else {
                    Save(head);
                    printf("ѧ����Ϣ�ѱ��浽�ļ���\n");
                }
                break;
            case 4:
                Take(&head);
                break;
            case 5:
                printf("����ѧ��: ");
                scanf("%d", &id);
                student = Search_num(head, id);
                if (student != NULL) {
                    Output(student);
                } else {
                    printf("δ�ҵ���ѧ����\n");
                }
                break;
            case 6:
                {
                    STU *new_student = (STU*)malloc(sizeof(STU));
                    printf("����ѧ��: ");
                    scanf("%d", &new_student->id);
                    printf("��������: ");
                    scanf("%s", new_student->name);
                    printf("����༶: ");
                    scanf("%s", new_student->clas);
                    printf("����רҵ: ");
                    scanf("%s", new_student->major);
                    printf("����3�ųɼ�: ");
                    for (int j = 0; j < 3; j++) {
                        scanf("%f", &new_student->scores[j]);
                    }
                    InsertList(&head, new_student);
                }
                break;
            case 7:
                printf("����ѧ��: ");
                scanf("%d", &id);
                Delete_num(&head, id);
                printf("ѧ����Ϣ��ɾ����\n");
                break;
            case 8:
                printf("����רҵ: ");
                scanf("%s", major);
                printf("����γ����� (0-2): ");
                scanf("%d", &subject_index);
                printf("����ɼ�: ");
                scanf("%f", &score);
                student = Search_major_subject_score(head, major, subject_index, score);
                if (student != NULL) {
                    Output(student);
                } else {
                    printf("δ�ҵ�����������ѧ����\n");
                }
                break;
            case 9:
                printf("����רҵ: ");
                scanf("%s", major);
                printf("����γ����� (0-2): ");
                scanf("%d", &subject_index);
                printf("����ɼ�: ");
                scanf("%f", &score);
                Delete_major_subject(&head, major, subject_index, score);
                printf("����������ѧ����ɾ����\n");
                break;
            case 0:
                // �ͷ������ڴ�
                while (head != NULL) {
                    STU *temp = head;
                    head = head->next;
                    free(temp);
                }
                exit(0);
            default:
                printf("��Ч��ѡ�����������롣\n");
        }
    }

    return 0;
}

